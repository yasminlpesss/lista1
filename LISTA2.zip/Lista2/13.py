idade = int(input("Digite a idade do trabalhador: "))
tempo_servico = int(input("Digite o tempo de serviço do trabalhador em anos: "))

if idade >= 65:
    print("O trabalhador pode se aposentar!")
elif tempo_servico >= 30:
    print("O trabalhador pode se aposentar!")
elif idade >= 60 and tempo_servico >= 25:
    print("O trabalhador pode se aposentar!")
else:
    print("O trabalhador ainda não pode se aposentar!")
