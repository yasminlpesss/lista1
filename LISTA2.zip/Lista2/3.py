numero = int(input("Digite um número inteiro: "))

if numero % 2 == 0:
    print(numero, "é par!")
else:
    print(numero, "é ímpar!")
