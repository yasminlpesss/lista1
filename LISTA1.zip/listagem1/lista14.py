valor = float(input("Digite o valor do produto: "))

valor_com_desconto = valor * 0.91

print(f"Valor com desconto de 9%: R${valor_com_desconto:.2f}")
