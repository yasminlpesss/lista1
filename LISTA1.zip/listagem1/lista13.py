razao = float(input("Digite a razão da PG: "))
primeiro_termo = float(input("Digite o primeiro termo da PG: "))

decimo_termo = primeiro_termo * razao ** 9

print("O décimo termo da PG é:", decimo_termo)
