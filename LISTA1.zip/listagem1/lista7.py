base = float(input("Digite a base do retângulo: "))
altura = float(input("Digite a altura do retângulo: "))

perimetro = 2 * (base + altura)
area = base * altura

print(f"Perímetro: {perimetro}")
print(f"Área: {area}")
