razao = float(input("Digite a razão da PA: "))
primeiro_termo = float(input("Digite o primeiro termo da PA: "))

decimo_termo = primeiro_termo + 9 * razao

print("O décimo termo da PA é:", decimo_termo)
