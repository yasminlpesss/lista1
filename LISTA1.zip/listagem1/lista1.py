numero = int(input("Digite um número inteiro: "))

quadrado = numero ** 2

print("O quadrado de", numero, "é", quadrado)
