raio = float(input("Digite o valor do raio da lata: "))
altura = float(input("Digite o valor da altura da lata: "))

PI = 3.1416
volume = PI * (raio ** 2) * altura

print(f"O volume da lata é: {volume:.1f}")