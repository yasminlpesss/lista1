diagonal_menor = float(input("Digite o valor da diagonal menor: "))
diagonal_maior = float(input("Digite o valor da diagonal maior: "))

area = (diagonal_menor * diagonal_maior) / 2

print(f"Área: {area:.1f}")
