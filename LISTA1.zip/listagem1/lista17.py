a = int(input("Digite o valor de A: "))
b = int(input("Digite o valor de B: "))

a, b = b, a

print("Valor de A após a troca:", a)
print("Valor de B após a troca:", b)
