numero = input("Digite um número no formato CDU: ")

numero_invertido = numero[::-1]

print(f"Número invertido: {numero_invertido}")
